<?php
session_start(); // Start the session

$servername = "localhost";
$username = "root";
$password = "brandon123";
$dbname = "rent_buddy";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is logged in
if (isset($_SESSION['UserID'])) {
    // User is logged in, retrieve the user's information from the database
    $userID = $_SESSION['UserID'];

    $userInfoSql = "SELECT Firstname FROM User WHERE UserID = ?";
    $stmt = $conn->prepare($userInfoSql);
    $stmt->bind_param("i", $userID);
    $stmt->execute();
    $stmt->bind_result($firstname);
    $stmt->fetch();
    $stmt->close();

    // Assign the user's first name to the $username variable
    $username = $firstname;
} else {
    // User is not logged in, redirect to the login page or handle it as per your requirements
    header("Location: login.php");
    exit();
}

// Retrieve car data from the database
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
$search = isset($_GET['search']) ? $_GET['search'] : '';
$sql = "SELECT * FROM car";

// Modify the SQL query to include the search condition
if (!empty($search)) {
    $sql .= " WHERE Model LIKE '%$search%'";
} else {
    if ($filter === 'available') {
        $sql .= " WHERE Status = 'Available'";
    } elseif ($filter === 'overdue') {
        $sql .= " WHERE Status = 'Overdue'";
    } elseif ($filter === 'rented') {
        $sql .= " WHERE Status = 'Rented'";
    }  elseif ($filter === 'returned') {
        $sql .= " WHERE Status = 'Returned'";
    }
}

$result = $conn->query($sql);

$cars = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $cars[] = $row;
    }
}

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Renter Cars</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            background-color: #f5f5f5;
        }

        .content {
            padding: 20px;
            margin-left: 300px;
            width: 1200px;
        }

        table {
            background-color: #fff;
            padding: 20px;
        }

        th, td {
            padding: 20px;
            text-align: center;
        }

        .sidebar {
            width: 200px;
            height: 100vh;
            background-color: black;
            color: white;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
        }

        .sidebar .nav-link {
            display: block;
            padding: 10px;
            color: white;
        }

        .sidebar .nav-link:hover {
            background-color: whitesmoke;
            color: black;
        }

        .sidebar .nav-item .active {
            background-color: whitesmoke;
            color: black;
        }

        .user-profile {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 20px;
        }

        .user-profile .avatar {
            font-size: 50px;
            margin-bottom: 10px;
        }

        .user-profile .username {
            margin: 0;
        }

        .filter-btn {
            background-color: black;
            border-color: black;
            color: white;
        }

        .filter-btn:hover {
            background-color: whitesmoke;
            border-color: black;
            color: black;
        }

        .filter-form {
            max-width: 200px;
            margin-bottom: 10px;
        }

        .form-control{
            width: 200px;
            border-color: black;
        }

    </style>
</head>
<body>
<div class="sidebar">
    <div class="user-profile">
        <span class="avatar"><i class="fas fa-user-circle"></i></span>
        <p class="username"><?php echo $username; ?></p>
    </div>
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) === 'RenterCarList.php') ? 'active' : ''; ?>" href="RenterCarList.php">View Available Cars</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) === 'RentCar.php') ? 'active' : ''; ?>" href="RenterViewCar.php">Your Cars</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) === 'logout.php') ? 'active' : ''; ?>" href="logout.php">Logout</a>
        </li>
    </ul>
</div>

<div class="content">
    <div class="col-lg">
        <div class="card mt-4">
            <div class="card-header border border-dark p-4">
                <h5 class="card-title">Available Cars for Rent</h5>
            </div>
            <div class="card-body border border-dark p-4">
        <div class="row">
            <div class="col-lg-8">
                <form class="filter-form" method="GET" action="RenterCarList.php">
                    <label>Filter by:</label>
                    <select class="form-control" name="filter">
                        <option value="all" <?php if ($filter === 'all') echo 'selected'; ?>>All</option>
                        <option value="available" <?php if ($filter === 'available') echo 'selected'; ?>>Available</option>
                        <option value="overdue" <?php if ($filter === 'overdue') echo 'selected'; ?>>Overdue</option>
                        <option value="rented" <?php if ($filter === 'rented') echo 'selected'; ?>>Rented</option>
                        <option value="returned" <?php if ($filter === 'returned') echo 'selected'; ?>>Returned</option>
                    </select>
                    <br />
                    <button class="btn filter-btn" type="submit" name="action">Apply Filter</button>
                </form>
            </div>
            <div class="col-lg-4">
                <form class="search-form" method="GET" action="RenterCarList.php">
                    <div class="input-group">
                        <br />
                        <input class="form-control" type="text" name="search" placeholder="Search By Car Model" value="<?php echo htmlspecialchars($search); ?>">
                        <div class="input-group-append">
                            <button class="btn filter-btn" type="submit">Search</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Car ID</th>
                                <th>Car No</th>
                                <th>Plates</th>
                                <th>Model</th>
                                <th>Type</th>
                                <th>Status</th>
                                <th>Cost Per Day</th>
                                <th>Overdue Cost Per Day</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($cars as $car): ?>
                                <tr>
                                    <td><?php echo $car['CarID']; ?></td>
                                    <td><?php echo $car['CarNo']; ?></td>
                                    <td><?php echo $car['Plates']; ?></td>
                                    <td><?php echo $car['Model']; ?></td>
                                    <td><?php echo $car['Type']; ?></td>
                                    <td><?php echo $car['Status']; ?></td>
                                    <td><?php echo $car['CostPerDay']; ?></td>
                                    <td><?php echo $car['CostPerDayOverdue']; ?></td>
                                    <td>
                                    <?php if ($car['Status'] === 'Available'): ?>
                                        <a class="btn filter-btn" href="RentCar.php?carID=<?php echo $car['CarID']; ?>">Rent Car</a>
                                    <?php elseif ($car['Status'] === 'Returned'): ?>
                                        <a class="btn filter-btn" href="RentCar.php?carID=<?php echo $car['CarID']; ?>">Rent Car</a>
                                    <?php elseif ($car['Status'] === 'Rented'): ?>
                                        <button class="btn btn-danger">Unavailable</button>
                                    <?php elseif ($car['Status'] === 'Overdue'): ?>
                                        <button class="btn btn-danger">Unavailable</button>
                                    <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
