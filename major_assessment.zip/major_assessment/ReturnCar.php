<?php
session_start(); // Start the session

$servername = "localhost";
$username = "root";
$password = "brandon123";
$dbname = "rent_buddy";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is logged in
if (isset($_SESSION['UserID'])) {
    // User is logged in, retrieve the user's information from the database
    $userID = $_SESSION['UserID'];

    $userInfoSql = "SELECT Firstname FROM User WHERE UserID = ?";
    $stmt = $conn->prepare($userInfoSql);
    $stmt->bind_param("i", $userID);
    $stmt->execute();
    $stmt->bind_result($firstname);
    $stmt->fetch();
    $stmt->close();

    // Assign the user's first name to the $username variable
    $username = $firstname;
} else {
    // User is not logged in, redirect to the login page or handle it as per your requirements
    header("Location: login.php");
    exit();
}


// Check if the car ID is provided
if (!isset($_POST['car_id'])) {
    // Car ID is not provided, redirect to the appropriate page or display an error message
    header("Location: RenterViewCar.php");
    exit();
}

// Retrieve the car ID from the form
$carID = $_POST['car_id'];

// Retrieve the rental information for the selected car
$rentalSql = "SELECT Rental.RentalID, Car.CarNo, Car.CostPerDay, Car.CostPerDayOverdue, Rental.RentalStartDate, Rental.RentalEndDate
              FROM Car
              INNER JOIN Rental ON Car.CarID = Rental.CarID
              WHERE Car.CarID = ? AND Rental.UserID = ? AND Car.Status = 'Rented'";

$stmt = $conn->prepare($rentalSql);
$stmt->bind_param("ii", $carID, $_SESSION['UserID']);
$stmt->execute();
$rentalResult = $stmt->get_result();

// Check if the rental record exists
if ($rentalResult->num_rows > 0) {
    $rental = $rentalResult->fetch_assoc();

    // Calculate the rental duration and overdue days
    $startDate = new DateTime($rental['RentalStartDate']);
    $endDate = new DateTime($rental['RentalEndDate']);
    $currentDate = new DateTime();
    $rentalDuration = $endDate->diff($startDate)->days + 1;
    $overdueDays = max(0, $currentDate->diff($endDate)->days); // Ensure the overdue days are not negative

    // Calculate the regular cost and the cost for overdue rent
    $regularCost = $rentalDuration * $rental['CostPerDay'];
    $overdueCost = $overdueDays * $rental['CostPerDayOverdue'];
    $totalCost = $regularCost;

    // Update the car status to 'Available' in the database
    $updateSql = "UPDATE Car SET Status = 'Available' WHERE CarID = ?";
    $stmt = $conn->prepare($updateSql);
    $stmt->bind_param("i", $carID);
    $stmt->execute();

    // Delete the rental record from the database
    $deleteSql = "DELETE FROM Rental WHERE RentalID = ?";
    $stmt = $conn->prepare($deleteSql);
    $stmt->bind_param("i", $rental['RentalID']);
    $stmt->execute();

    // Close the prepared statement
    $stmt->close();
}

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Return Car</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <style>
        body {
            background-color: #f5f5f5;
        }

        .content {
            padding: 20px;
            margin-left: 500px;
            margin-top: 50px;
            width: 600px;
        }


        .sidebar {
            width: 200px;
            height: 100vh;
            background-color: black;
            color: white;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
        }

        .sidebar .nav-link {
            display: block;
            padding: 10px;
            color: white;
        }

        .sidebar .nav-link:hover {
            background-color: whitesmoke;
            color: black;
        }

        .sidebar .nav-item .active {
            background-color: whitesmoke;
            color: black;
        }

        .user-profile {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 20px;
        }

        .user-profile .avatar {
            font-size: 50px;
            margin-bottom: 10px;
        }

        .user-profile .username {
            margin: 0;
        }

        .rent-btn {
            background-color: black;
            border-color: black;
            color: white;
        }

        .rent-btn:hover {
            background-color: whitesmoke;
            border-color: black;
            color: black;
        }
    </style>
</head>
<body>
<div class="sidebar">
    <div class="user-profile">
        <span class="avatar"><i class="fas fa-user-circle"></i></span>
        <p class="username"><?php echo $username; ?></p>
    </div>
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) === 'AdminCarList.php') ? 'active' : ''; ?>" href="AdminCarList.php">View Cars</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) === 'AdminInsertCar.php') ? 'active' : ''; ?>" href="AdminInsertCar.php">Insert Car</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) === 'AdminList.php') ? 'active' : ''; ?>" href="AdminList.php">Manage Users</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) === 'logout.php') ? 'active' : ''; ?>" href="logout.php">Logout</a>
        </li>
    </ul>
</div>


    <div class="content">
    <div class="card mt-4">
        <div class="card-header border border-dark p-4">
            <h5 class="card-title">Return Car</h5>
        </div>
        <div class="card-body border border-dark p-4">
            <?php if (isset($rental) && $rentalResult->num_rows > 0): ?>
                <div class="message alert alert-success">
                    <p>Car No: <?php echo $rental['CarNo']; ?> has been returned successfully.</p>
                </div>
                <div class="card border border-dark">
                    <div class="card-body">
                        <p><b>Car No: </b><?php echo $rental['CarNo']; ?></p>
                        <p><b>Start Date: </b><?php echo $rental['RentalStartDate']; ?></p>
                        <p><b>End Date: </b><?php echo $rental['RentalEndDate']; ?></p>
                        <p><b>Regular Cost: </b><?php echo $regularCost; ?></p>
                        <?php if ($overdueDays > 0): ?>
                            <p><b>Cost for Overdue Rent: </b><?php echo $overdueCost; ?></p>
                        <?php else: ?>
                            <style>.overdue-cost { display: none; }</style>
                            <p class="overdue-cost"><b>Overdue Cost: </b></p>
                        <?php endif; ?>
                        <p><b>Total Cost: </b><?php echo $totalCost; ?></p> 
                    </div>
                </div>
                <a class="btn rent-btn mt-4" href="RenterViewCar.php">Back</a>
            <?php else: ?>
                <div class="message alert alert-danger">
                    <p>Unable to return the car. Please try again or contact the administrator.</p>
                </div>
                <a class="btn rent-btn mt-4" href="RenterViewCar.php">Back</a>
            <?php endif; ?>
        </div>
    </div>
</div>

</body>
</html>
