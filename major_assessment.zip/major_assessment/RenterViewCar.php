<?php
session_start(); // Start the session

$servername = "localhost";
$username = "root";
$password = "brandon123";
$dbname = "rent_buddy";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is logged in
if (isset($_SESSION['UserID'])) {
    // User is logged in, retrieve the user's information from the database
    $userID = $_SESSION['UserID'];

    $userInfoSql = "SELECT Firstname FROM User WHERE UserID = ?";
    $stmt = $conn->prepare($userInfoSql);
    $stmt->bind_param("i", $userID);
    $stmt->execute();
    $stmt->bind_result($firstname);
    $stmt->fetch();
    $stmt->close();

    // Assign the user's first name to the $username variable
    $username = $firstname;
} else {
    // User is not logged in, redirect to the login page or handle it as per your requirements
    header("Location: login.php");
    exit();
}

// Check if the filter is applied
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';

// Prepare the filter condition
$filterCondition = '';
if ($filter == 'rented') {
    $filterCondition = "AND Car.Status = 'Rented'";
} elseif ($filter == 'overdue') {
    $filterCondition = "AND Car.Status = 'Overdue'";
} elseif ($filter == 'returned') {
    $filterCondition = "AND Car.Status = 'Returned'";
}

// Retrieve the rented and overdue cars with the status, cost overdue per day, and total cost
$carsSql = "SELECT Car.CarID, Car.CarNo, Car.Plates, Car.Status, Car.Model, Car.Type, Car.CostPerDay, Car.CostPerDayOverdue, Rental.RentalStartDate, Rental.RentalEndDate, DATEDIFF(CURDATE(), Rental.RentalEndDate) * Car.CostPerDay AS CostOverdueDay, (DATEDIFF(Rental.RentalEndDate, Rental.RentalStartDate) + 1) * Car.CostPerDay + DATEDIFF(CURDATE(), Rental.RentalEndDate) * Car.CostPerDay AS TotalCost
            FROM Car
            INNER JOIN Rental ON Car.CarID = Rental.CarID
            WHERE Rental.UserID = ? $filterCondition";

$stmt = $conn->prepare($carsSql);
$stmt->bind_param("i", $userID);
$stmt->execute();
$carsResult = $stmt->get_result();

// Close the prepared statement
$stmt->close();

$stmt = $conn->prepare($carsSql);
$stmt->bind_param("i", $userID);
$stmt->execute();
$carsResult = $stmt->get_result();

// Close the prepared statement
$stmt->close();

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Renter View Cars</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            background-color: #f5f5f5;
        }

        .content {
            padding: 20px;
            margin-left: 300px;
            width: 1200px;
        }

        table {
            background-color: #fff;
            padding: 20px;
        }

        th, td {
            padding: 20px;
            text-align: center;
        }

        .sidebar {
            width: 200px;
            height: 100vh;
            background-color: black;
            color: white;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
        }

        .sidebar .nav-link {
            display: block;
            padding: 10px;
            color: white;
        }

        .sidebar .nav-link:hover {
            background-color: whitesmoke;
            color: black;
        }

        .sidebar .nav-item .active {
            background-color: whitesmoke;
            color: black;
        }

        .user-profile {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 20px;
        }

        .user-profile .avatar {
            font-size: 50px;
            margin-bottom: 10px;
        }

        .user-profile .username {
            margin: 0;
        }

        .rent-btn {
            background-color: black;
            border-color: black;
            color: white;
        }

        .rent-btn:hover {
            background-color: whitesmoke;
            border-color: black;
            color: black;
        }

        .form-control{
            width: 200px;
            border-color: black;
        }

        

    </style>
</head>
<body>
    <div class="sidebar">
        <div class="user-profile">
            <span class="avatar"><i class="fas fa-user-circle"></i></span>
            <p class="username"><?php echo $username; ?></p>
        </div>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) === 'RenterCarList.php') ? 'active' : ''; ?>" href="RenterCarList.php">View Available Cars</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) === 'RentCar.php') ? 'active' : ''; ?>" href="RenterViewCar.php">Your Cars</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) === 'logout.php') ? 'active' : ''; ?>" href="logout.php">Logout</a>
            </li>
        </ul>
    </div>

    <div class="content">
    <div class="col-lg">
        <div class="card mt-4">
            <div class="card-header border border-dark p-4">
                <h5 class="card-title">Your Cars</h5>
            </div>
            <div class="card-body border border-dark p-4">
                <form method="GET" action="ReturnCar.php">
                    <label for="filter">Filter by:</label>
                    <select id="filter" name="filter" class="form-control">
                        <option value="all" <?php echo ($filter == 'all') ? 'selected' : ''; ?>>All</option>
                        <option value="rented" <?php echo ($filter == 'rented') ? 'selected' : ''; ?>>Rented</option>
                        <option value="overdue" <?php echo ($filter == 'overdue') ? 'selected' : ''; ?>>Overdue</option>
                        <option value="returned" <?php echo ($filter == 'returned') ? 'selected' : ''; ?>>Returned</option>
                    </select>
                    <br />
                    <button type="submit" class="btn rent-btn">Apply Filter</button>
                </form>
                <br />
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Car Number</th>
                                <th>Plates</th>
                                <th>Model</th>
                                <th>Type</th>
                                <th>Cost Per Day</th>
                                <th>Rental Start Date</th>
                                <th>Rental End Date</th>
                                <th>Cost Overdue Per Day</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $carsResult->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $row['CarNo']; ?></td>
                                    <td><?php echo $row['Plates']; ?></td>
                                    <td><?php echo $row['Model']; ?></td>
                                    <td><?php echo $row['Type']; ?></td>
                                    <td><?php echo $row['CostPerDay']; ?></td>
                                    <td><?php echo $row['RentalStartDate']; ?></td>
                                    <td><?php echo $row['RentalEndDate']; ?></td>
                                    <td><?php echo $row['CostPerDayOverdue']; ?></td>
                                    <td>
                                        <form method="post" action="ReturnCar.php">
                                            <input type="hidden" name="car_id" value="<?php echo $row['CarID']; ?>">
                                            <input type="hidden" name="cost_per_day" value="<?php echo $row['CostPerDay']; ?>">
                                            <input type="hidden" name="cost_per_day_overdue" value="<?php echo $row['CostPerDayOverdue']; ?>">
                                            <button type="submit" class="btn rent-btn">Return Car</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>


