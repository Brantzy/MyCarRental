<?php
session_start(); // Start the session

$servername = "localhost";
$username = "root";
$password = "brandon123";
$dbname = "rent_buddy";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Handle the login form submission
    // Retrieve form data
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Check if email and password are correct
    $sql = "SELECT UserID, hashedPassword, UserType FROM User WHERE Email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($userID, $hashedPassword, $userType);
        $stmt->fetch();

        if (password_verify($password, $hashedPassword)) {
            // Password is correct, set the user ID and type in the session
            $_SESSION["UserID"] = $userID;
            $_SESSION["UserType"] = $userType;

            // Redirect to the appropriate page based on user type
            if ($userType === "Administrator") {
                header("Location: AdminCarList.php");
                exit();
            } elseif ($userType === "Renter") {
                header("Location: RenterCarList.php");
                exit();
            }
        } else {
            $errorMsg = "Incorrect password";
        }
    } else {
        $errorMsg = "Email not found";
    }

    $stmt->close();
}

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 80vh;
            background-color: #f5f5f5;
        }

        .form-control {
            border-color: black;
        }


    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card mt-5">
                    <div class="card-body border border-dark p-4">
                        <h2 class="text-center font-weight-bold mb-4">User Login</h2>
                        <br>
                        <form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
                            <div class="form-group">
                                <label for="email">Email:</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="form-group">
                                <label for="password">Password:</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <br>
                            <div class="text-center">
                                <button type="submit" class="btn btn-dark">Login</button>
                                <a href="register.php" class="btn btn-dark">Register</a>
                            </div>
                            <?php
                            if (isset($errorMsg)) {
                                echo '<div class="alert alert-danger mt-4">' . $errorMsg . '</div>';
                            }
                            ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
