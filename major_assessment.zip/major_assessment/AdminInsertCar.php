<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "brandon123";
$dbname = "rent_buddy";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is logged in
if (isset($_SESSION['UserID'])) {
    // User is logged in, retrieve the user's information from the database
    $userID = $_SESSION['UserID'];
    
    $userInfoSql = "SELECT Firstname FROM User WHERE UserID = ?";
    $stmt = $conn->prepare($userInfoSql);
    $stmt->bind_param("i", $userID);
    $stmt->execute();
    $stmt->bind_result($firstname);
    $stmt->fetch();
    $stmt->close();
    
    // Assign the user's first name to the $username variable
    $username = $firstname;
} else {
    // User is not logged in, redirect to the login page or handle it as per your requirements
    header("Location: login.php");
    exit();
}

// Define an array to store error messages
$errors = array();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $carNo = $_POST["carNo"];
    $plates = $_POST["plates"];
    $model = $_POST["model"];
    $type = $_POST["type"];
    $status = $_POST["status"];
    $costPerDay = $_POST["costPerDay"];
    $costPerDayOverdue = $_POST["costPerDayOverdue"];

    // Validate form data (you can add your own validation rules)
    if (empty($carNo)) {
        $errors[] = "Car Number is required";
    }
    if (empty($plates)) {
        $errors[] = "Plates is required";
    }
    if (empty($model)) {
        $errors[] = "Model is required";
    }
    if (empty($type)) {
        $errors[] = "Type is required";
    }
    if (empty($status)) {
        $errors[] = "Status is required";
    }
    if (empty($costPerDay)) {
        $errors[] = "Cost Per Day is required";
    }
    if (empty($costPerDayOverdue)) {
        $errors[] = "Cost Per Day Overdue is required";
    }

    // Proceed with car insertion if there are no errors
    if (empty($errors)) {
        // Prepare and execute the SQL statement
        $stmt = $conn->prepare("INSERT INTO Car (CarNo, Plates, Model, Type, Status, CostPerDay, CostPerDayOverdue)
                                VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssd", $carNo, $plates, $model, $type, $status, $costPerDay, $costPerDayOverdue);

        if ($stmt->execute()) {
            $successMessage = "Car added successfully. You will be redirected to the car list page.";
            echo '<script>setTimeout(function() { window.location.href = "AdminCarList.php"; }, 2000);</script>';
        } else {
            $errors[] = "An error occurred. " . $stmt->error;
        }

        $stmt->close();
    }
}

// Close the connection
$conn->close();
?>


<!DOCTYPE html>
<html>
<head>
    <title>Insert Car</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            background-color: #f5f5f5;
        }

        .content {
            padding: 20px;
            margin-left: 500px;
            margin-top: 50px;
            width: 800px;
        }
    
        .sidebar {
            width: 200px;
            height: 100vh;
            background-color: teal;
            color: white;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
        }

        .sidebar .nav-link {
            display: block;
            padding: 10px;
            color: white;
        }

        .sidebar .nav-link:hover {
            background-color: whitesmoke;
            color: teal;
        }

        .sidebar .nav-item .active {
            background-color: whitesmoke;
            color: teal;
        }
        
        .user-profile {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 20px;
        }

        .user-profile .avatar {
            font-size: 50px;
            margin-bottom: 10px;
        }

        .user-profile .username {
            margin: 0;
        }

        .filter-btn {
            background-color: teal;
            border-color: teal;
            color: white;
        }

        .filter-btn:hover {
            background-color: whitesmoke;
            border-color: teal;
            color: teal;
        }
    </style>
</head>
<body>
<div class="sidebar">
    <div class="user-profile">
        <span class="avatar"><i class="fas fa-user-circle"></i></span>
        <p class="username"><?php echo $username; ?></p>
    </div>
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) === 'AdminCarList.php') ? 'active' : ''; ?>" href="AdminCarList.php">View Cars</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) === 'AdminInsertCar.php') ? 'active' : ''; ?>" href="AdminInsertCar.php">Insert Car</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) === 'AdminList.php') ? 'active' : ''; ?>" href="AdminList.php">Manage Users</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) === 'logout.php') ? 'active' : ''; ?>" href="logout.php">Logout</a>
        </li>
    </ul>
</div>

<div class="content">
    <div class="card">
        <div class="card-body">
            <h5 class="card-title text-center">New Car</h5>
            <b><hr /></b>
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="carNo">Car Number</label>
                        <input type="text" class="form-control" id="carNo" name="carNo">
                    </div>
                    <div class="form-group col-md-6">
                        <label for="plates">Plates</label>
                        <input type="text" class="form-control" id="plates" name="plates">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="model">Model</label>
                        <input type="text" class="form-control" id="model" name="model">
                    </div>
                    <div class="form-group col-md-6">
                        <label for="type">Type</label>
                        <input type="text" class="form-control" id="type" name="type">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="status">Status</label>
                        <select class="form-control" id="status" name="status" required>
                            <option value="" disabled selected>Select Status</option>
                            <option value="Available">Available</option>
                            <option value="Rented">Rented</option>
                            <option value="Overdue">Overdue</option>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="costPerDay">Cost Per Day</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">$</span>
                            </div>
                            <input type="number" class="form-control" id="costPerDay" name="costPerDay" step="0.01">
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label for="costPerDayOverdue">Cost Per Day Overdue</label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">$</span>
                        </div>
                        <input type="number" class="form-control" id="costPerDayOverdue" name="costPerDayOverdue" step="0.01">
                    </div>
                </div>
                <div class="form-group text-center">
                    <button class="btn filter-btn" type="submit" name="submit">Submit</button>
                </div>
                <?php
                if (!empty($errors)) {
                    foreach ($errors as $error) {
                        echo '<div class="alert alert-danger">' . $error . '</div>';
                    }
                }
                if (isset($successMessage)) {
                    echo '<div class="alert alert-success">' . $successMessage . '</div>';
                }
                ?>
            </form>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>
