<?php
$servername = "localhost";
$username = "root";
$password = "brandon123";
$dbname = "rent_buddy";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $firstname = $_POST["firstname"];
    $surname = $_POST["surname"];
    $phone = $_POST["phone"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $userType = $_POST["userType"];

    // Check if the email is already registered
    $sql = "SELECT UserID FROM User WHERE Email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // Email is already registered
        $errorMsg = "Email is already registered";
    } else {
        // Insert the new user into the database
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO User (Firstname, Surname, Phone, Email, hashedPassword, UserType) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssss", $firstname, $surname, $phone, $email, $hashedPassword, $userType);
        if ($stmt->execute()) {
            // User registration successful
            $successMsg = "User registration successful. You will be redirected to the login page";
            echo '<script>setTimeout(function() { window.location.href = "login.php"; }, 2000);</script>';
        } else {
            // Error occurred while registering the user
            $errorMsg = "Error occurred while registering the user";
        }
    }

    $stmt->close();
}

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f5f5f5;
        }

        .form-control {
            border-color: black;
        }

    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card mt-5">
                    <div class="card-body border border-dark p-4">
                        <h2 class="text-center font-weight-bold mb-4">User Registration</h2>
                        <br />
                        <form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
                            <div class="form-group">
                                <label for="firstname">First Name:</label>
                                <input type="text" class="form-control" id="firstname" name="firstname" required>
                            </div>
                            <div class="form-group">
                                <label for="surname">Surname:</label>
                                <input type="text" class="form-control" id="surname" name="surname" required>
                            </div>
                            <div class="form-group">
                                <label for="phone">Phone:</label>
                                <input type="text" class="form-control" id="phone" name="phone" required>
                            </div>
                            <div class="form-group">
                                <label for="email">Email:</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="form-group">
                                <label for="password">Password:</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <div class="form-group">
                                <label for="userType">User Type:</label>
                                <select class="form-control" id="userType" name="userType">
                                    <option value="Administrator">Administrator</option>
                                    <option value="Renter">Renter</option>
                                </select>
                            </div>
                            <br />
                            <div class="text-center">
                                <button type="submit" class="btn btn-dark">Register</button>
                                <a href="login.php" class="btn btn-dark">Login</a>
                            </div>
                            <br />
                            <?php
                            if (isset($successMsg)) {
                                echo '<div class="alert alert-success">' . $successMsg . '</div>';
                            }
                            if (isset($errorMsg) && !empty($errorMsg)) {
                                echo '<div class="alert alert-danger">' . $errorMsg . '</div>';
                            }
                            ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
