<?php
$servername = "localhost";
$username = "root";
$password = "brandon123";
$dbname = "rent_buddy";

// Create a connection
$conn = new mysqli($servername, $username, $password);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create the database
$sql = "CREATE DATABASE IF NOT EXISTS $dbname";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully<br>";
} else {
    echo "Error creating database: " . $conn->error;
    $conn->close();
    exit();
}

// Select the newly created database
$conn->select_db($dbname);

// Create the User table
$sql = "CREATE TABLE IF NOT EXISTS User (
    UserID INT(11) AUTO_INCREMENT PRIMARY KEY,
    Firstname VARCHAR(50) NOT NULL,
    Surname VARCHAR(50) NOT NULL,
    Phone VARCHAR(20) NOT NULL,
    Email VARCHAR(100) NOT NULL,
    UserType ENUM('Administrator', 'Renter') NOT NULL
)";
if ($conn->query($sql) === TRUE) {
    echo "User table created successfully<br>";
} else {
    echo "Error creating User table: " . $conn->error;
    $conn->close();
    exit();
}

// Add the hashedPassword column to the User table
$sql = "ALTER TABLE User ADD hashedPassword VARCHAR(255) NOT NULL AFTER Email";
if ($conn->query($sql) === TRUE) {
    echo "Column 'hashedPassword' added to the User table<br>";
} else {
    echo "Error adding column: " . $conn->error;
    $conn->close();
    exit();
}

// Create the Car table
$sql = "CREATE TABLE IF NOT EXISTS Car (
    CarID INT(11) AUTO_INCREMENT PRIMARY KEY,
    CarNo VARCHAR(50) NOT NULL,
    Plates VARCHAR(50) NOT NULL,
    Model VARCHAR(50) NOT NULL,
    Type VARCHAR(50) NOT NULL,
    Status ENUM('Available', 'Rented', 'Overdue', 'Returned') NOT NULL DEFAULT 'Available',
    CostPerDay DECIMAL(10, 2) NOT NULL,
    CostPerDayOverdue DECIMAL(10, 2) NOT NULL
)";
if ($conn->query($sql) === TRUE) {
    echo "Car table created successfully with 'Returned' status<br>";
} else {
    echo "Error creating Car table: " . $conn->error;
    $conn->close();
    exit();
}

// Create the Rental table
$sql = "CREATE TABLE IF NOT EXISTS Rental (
    RentalID INT(11) AUTO_INCREMENT PRIMARY KEY,
    CarID INT(11) NOT NULL,
    UserID INT(11) NOT NULL,
    RentalStartDate DATE NOT NULL,
    RentalEndDate DATE NOT NULL,
    TotalCost DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (CarID) REFERENCES Car(CarID),
    FOREIGN KEY (UserID) REFERENCES User(UserID)
)";
if ($conn->query($sql) === TRUE) {
    echo "Rental table created successfully<br>";
} else {
    echo "Error creating Rental table: " . $conn->error;
    $conn->close();
    exit();
}

// Close the connection
$conn->close();
?>
