<?php
session_start();

// Your server-side code for retrieving user information
$servername = "localhost";
$username = "root";
$password = "brandon123";
$dbname = "rent_buddy";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is logged in
if (isset($_SESSION['UserID'])) {
    // User is logged in, retrieve the user's information from the database
    $userID = $_SESSION['UserID'];
    
    $userInfoSql = "SELECT Firstname FROM User WHERE UserID = ?";
    $stmt = $conn->prepare($userInfoSql);
    $stmt->bind_param("i", $userID);
    $stmt->execute();
    $stmt->bind_result($firstname);
    $stmt->fetch();
    $stmt->close();
    
    // Assign the user's first name to the $username variable
    $username = $firstname;
} else {
    // User is not logged in, redirect to the login page or handle it as per your requirements
    header("Location: login.php");
    exit();
}

// Delete user function
if (isset($_GET['delete'])) {
    $userId = $_GET['delete'];
    $deleteSql = "DELETE FROM User WHERE UserID = $userId";
    if ($conn->query($deleteSql) === TRUE) {
        // User deleted successfully
    } else {
        echo "Error deleting user: " . $conn->error;
    }
}

// Retrieve user data from the database
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
$sql = "SELECT * FROM User";
if ($filter === 'administrator') {
    $sql .= " WHERE UserType = 'Administrator'";
} elseif ($filter === 'renter') {
    $sql .= " WHERE UserType = 'Renter'";
}

$result = $conn->query($sql);

$users = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
}

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>User List</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            background-color: #f5f5f5;
        }

        .content {
            padding: 20px;
            margin-left: 300px;
            width: 1200px;
        }

        table {
            background-color: #fff;
            padding: 20px;
        }

        th, td {
            padding: 20px;
            text-align: center;
        }

        .sidebar {
            width: 200px;
            height: 100vh;
            background-color: teal;
            color: white;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
        }

        .sidebar .nav-link {
            display: block;
            padding: 10px;
            color: white;
        }

        .sidebar .nav-link:hover {
            background-color: whitesmoke;
            color: teal;
        }

        .sidebar .nav-item .active {
            background-color: whitesmoke;
            color: teal;
        }
        
        .user-profile {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 20px;
        }

        .user-profile .avatar {
            font-size: 50px;
            margin-bottom: 10px;
        }

        .user-profile .username {
            margin: 0;
        }

        .filter-btn {
            background-color: teal;
            border-color: teal;
            color: white;
        }

        .filter-btn:hover {
            background-color: whitesmoke;
            border-color: teal;
            color: teal;
        }
        
        .filter-form {
            max-width: 200px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="user-profile">
        <span class="avatar"><i class="fas fa-user-circle"></i></span>
        <p class="username"><?php echo $username; ?></p>
    </div>
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) === 'AdminCarList.php') ? 'active' : ''; ?>" href="AdminCarList.php">View Cars</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) === 'AdminInsertCar.php') ? 'active' : ''; ?>" href="AdminInsertCar.php">Insert Car</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) === 'AdminList.php') ? 'active' : ''; ?>" href="AdminList.php">Manage Users</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) === 'logout.php') ? 'active' : ''; ?>" href="logout.php">Logout</a>
        </li>
    </ul>
</div>

<div class="content">
    <div class="col-lg">
        <div class="card mt-4">
            <div class="card-header">
                <h5 class="card-title">User List</h5>
            </div>
            <div class="card-body">
                <form action="AdminList.php" method="GET" class="filter-form">
                    <div class="form-group">
                        <label>Filter by:</label>
                        <select name="filter" class="form-control">
                            <option value="all" <?php echo ($filter === 'all') ? 'selected' : ''; ?>>All</option>
                            <option value="administrator" <?php echo ($filter === 'administrator') ? 'selected' : ''; ?>>Administrator</option>
                            <option value="renter" <?php echo ($filter === 'renter') ? 'selected' : ''; ?>>Renter</option>
                        </select>
                        <br />
                        <button class="btn filter-btn" type="submit">Apply Filter</button>
                    </div>
                </form>

                <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>User ID</th>
                            <th>First Name</th>
                            <th>Surname</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>User Type</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?php echo $user['UserID']; ?></td>
                            <td><?php echo $user['Firstname']; ?></td>
                            <td><?php echo $user['Surname']; ?></td>
                            <td><?php echo $user['Phone']; ?></td>
                            <td><?php echo $user['Email']; ?></td>
                            <td><?php echo $user['UserType']; ?></td>
                            <td>
                                <a href="?delete=<?php echo $user['UserID']; ?>" onclick="return confirm('Are you sure you want to delete this user?')" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
        </div>


<!-- Bootstrap JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>
