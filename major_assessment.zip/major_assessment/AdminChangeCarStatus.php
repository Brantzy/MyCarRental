<?php
session_start();

// Your server-side code for retrieving car information
$servername = "localhost";
$username = "root";
$password = "brandon123";
$dbname = "rent_buddy";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is logged in
if (isset($_SESSION['UserID'])) {
    // User is logged in, retrieve the user's information from the database
    $userID = $_SESSION['UserID'];
    
    $userInfoSql = "SELECT Firstname FROM User WHERE UserID = ?";
    $stmt = $conn->prepare($userInfoSql);
    $stmt->bind_param("i", $userID);
    $stmt->execute();
    $stmt->bind_result($firstname);
    $stmt->fetch();
    $stmt->close();
    
    // Assign the user's first name to the $username variable
    $username = $firstname;
} else {
    // User is not logged in, redirect to the login page or handle it as per your requirements
    header("Location: login.php");
    exit();
}


// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the car ID from the URL parameter
    $carId = $_GET['carId'];
    
    // Retrieve the new status from the form
    $newStatus = $_POST['status'];

    // Update the car status in the database
    $updateSql = "UPDATE car SET Status = '$newStatus' WHERE CarID = $carId";
    if ($conn->query($updateSql) === TRUE) {
        // Car status updated successfully
        header("Location: AdminCarList.php"); // Redirect back to the car list page
        exit();
    } else {
        echo "Error updating car status: " . $conn->error;
    }
}

// Retrieve the car details based on the car ID from the URL parameter
$carId = $_GET['carId'];
$sql = "SELECT * FROM car WHERE CarID = $carId";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $car = $result->fetch_assoc();
} else {
    echo "Car not found";
    exit();
}

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Change Car Status</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            background-color: #f5f5f5;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        }

        .card-title {
            font-size: 22px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        th {
            font-weight: bold;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .content {
            padding: 20px;
            margin-left: 300px;
            width: 1200px;
        }

        .sidebar {
            width: 200px;
            height: 100vh;
            background-color: teal;
            color: white;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
        }

        .sidebar .nav-link {
            display: block;
            padding: 10px;
            color: white;
        }

        .sidebar .nav-link:hover {
            background-color: whitesmoke;
            color: teal;
        }

        .sidebar .nav-item .active {
            background-color: whitesmoke;
            color: teal;
        }
        
        .user-profile {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 20px;
        }

        .user-profile .avatar {
            font-size: 50px;
            margin-bottom: 10px;
        }

        .user-profile .username {
            margin: 0;
        }

        .filter-btn {
            background-color: teal;
            border-color: teal;
            color: white;
            width: 200px;
        }

        .filter-btn:hover {
            background-color: whitesmoke;
            border-color: teal;
            color: teal;
        }

        .form-control{
            width: 200px;
            border-color: black;
        }
        
    </style>
</head>
<body>
<div class="sidebar">
    <div class="user-profile">
        <span class="avatar"><i class="fas fa-user-circle"></i></span>
        <p class="username"><?php echo $username; ?></p>
    </div>
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) === 'AdminCarList.php') ? 'active' : ''; ?>" href="AdminCarList.php">View Cars</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) === 'AdminInsertCar.php') ? 'active' : ''; ?>" href="AdminInsertCar.php">Insert Car</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) === 'AdminList.php') ? 'active' : ''; ?>" href="AdminList.php">Manage Users</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) === 'logout.php') ? 'active' : ''; ?>" href="logout.php">Logout</a>
        </li>
    </ul>
    </div>
    <div class="container">
        <h5 class="card-title">Car Information</h5>
        <table class="table">
            <tbody>
                <tr>
                    <th>Car ID:</th>
                    <td><?php echo $car['CarID']; ?></td>
                </tr>
                <tr>
                    <th>Car No:</th>
                    <td><?php echo $car['CarNo']; ?></td>
                </tr>
                <tr>
                    <th>Plates:</th>
                    <td><?php echo $car['Plates']; ?></td>
                </tr>
                <tr>
                    <th>Model:</th>
                    <td><?php echo $car['Model']; ?></td>
                </tr>
                <tr>
                    <th>Type:</th>
                    <td><?php echo $car['Type']; ?></td>
                </tr>
                <tr>
                    <th>Status:</th>
                    <td><?php echo $car['Status']; ?></td>
                </tr>
                <tr>
                    <th>Cost Per Day:</th>
                    <td><?php echo $car['CostPerDay']; ?></td>
                </tr>
                <tr>
                    <th>Overdue Cost Per Day:</th>
                    <td><?php echo $car['CostPerDayOverdue']; ?></td>
                </tr>
            </tbody>
        </table>
        <br>
        <form method="POST">
            <div class="form-group">
                <label for="status">Change Car Status:</label>
                <select class="form-control" id="status" name="status">
                    <option value="available" <?php if ($car['Status'] == 'available') echo 'selected'; ?>>Available</option>
                    <option value="rented" <?php if ($car['Status'] == 'rented') echo 'selected'; ?>>Rented</option>
                    <option value="overdue" <?php if ($car['Status'] == 'overdue') echo 'selected'; ?>>Overdue</option>
                </select>
            </div>
            <button class="btn filter-btn" type="submit">Change Status</button>
        </form>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>


