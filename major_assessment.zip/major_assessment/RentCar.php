<?php
session_start(); // Start the session

$servername = "localhost";
$username = "root";
$password = "brandon123";
$dbname = "rent_buddy";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is logged in
if (isset($_SESSION['UserID'])) {
    // User is logged in, retrieve the user's information from the database
    $userID = $_SESSION['UserID'];

    $userInfoSql = "SELECT Firstname FROM User WHERE UserID = ?";
    $stmt = $conn->prepare($userInfoSql);
    $stmt->bind_param("i", $userID);
    $stmt->execute();
    $stmt->bind_result($firstname);
    $stmt->fetch();
    $stmt->close();

    // Assign the user's first name to the $username variable
    $username = $firstname;
} else {
    // User is not logged in, redirect to the login page or handle it as per your requirements
    header("Location: login.php");
    exit();
}

// Check if the carID is provided as a parameter
if (!isset($_GET['carID'])) {
    // carID is missing, redirect to the available cars page or handle it as per your requirements
    header("Location: RenterCarList.php");
    exit();
}

$carID = $_GET['carID'];

// Retrieve car information
$carInfoSql = "SELECT * FROM Car WHERE CarID = ?";
$stmt = $conn->prepare($carInfoSql);
$stmt->bind_param("i", $carID);
$stmt->execute();
$carResult = $stmt->get_result();

// Check if the car exists
if ($carResult->num_rows === 0) {
    // Car does not exist, redirect to the available cars page or handle it as per your requirements
    header("Location: RenterCarList.php");
    exit();
}

// Fetch car details
$car = $carResult->fetch_assoc();

$stmt->close();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Process the rental request
    
    // Get the user ID from the session
    $userID = $_SESSION['UserID'];
    
    // Get the rental details from the form
    $startDate = $_POST['start_date'];
    $endDate = $_POST['end_date'];
    
    // Perform validation checks for rent dates
    $today = date("Y-m-d");
    if ($startDate < $today || $endDate < $today) {
        // Display an error message if the rent dates are before today
        $errorMessage = "Invalid rent dates. Please select dates from today onwards.";
    } else {
        // Calculate the total cost (you may have your own logic to calculate this based on the rental duration and car price)
        $totalCost = calculateTotalCost($startDate, $endDate, $car['CostPerDay']);
        
        // Insert the rental record into the database
        $insertSql = "INSERT INTO Rental (CarID, UserID, RentalStartDate, RentalEndDate, TotalCost) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insertSql);
        $stmt->bind_param("iisss", $carID, $userID, $startDate, $endDate, $totalCost);
        $stmt->execute();
        $stmt->close();
        
        // Update the car status to 'Rented'
        $updateSql = "UPDATE Car SET Status = 'Rented' WHERE CarID = ?";
        $stmt = $conn->prepare($updateSql);
        $stmt->bind_param("i", $carID);
        $stmt->execute();
        $stmt->close();

        // Set the success message
        $successMessage = "Car rented successfully. You will be redirect to the previous page";
        
        // Execute JavaScript function to redirect after 2 seconds
        echo '<script>setTimeout(function() { window.location.href = "RenterViewCar.php"; }, 2000);</script>';

        
    }
}

// Function to calculate the total cost based on rental duration and car price per day
function calculateTotalCost($startDate, $endDate, $costPerDay) {
    $startTimestamp = strtotime($startDate);
    $endTimestamp = strtotime($endDate);
    $rentalDuration = ceil(($endTimestamp - $startTimestamp) / (60 * 60 * 24)); // Calculate the duration in days
    $totalCost = $rentalDuration * $costPerDay;
    return $totalCost;
}

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Rent Car</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            background-color: #f5f5f5;
        }

        .content {
            padding: 20px;
            margin-left: 500px;
            margin-top: 50px;
            width: 600px;
        }

        table {
            background-color: #fff;
            padding: 20px;
        }

        th, td {
            padding: 20px;
            text-align: center;
        }

        .sidebar {
            width: 200px;
            height: 100vh;
            background-color: black;
            color: white;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
        }

        .sidebar .nav-link {
            display: block;
            padding: 10px;
            color: white;
        }

        .sidebar .nav-link:hover {
            background-color: whitesmoke;
            color: black;
        }

        .sidebar .nav-item .active {
            background-color: whitesmoke;
            color: black;
        }

        .user-profile {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 20px;
        }

        .user-profile .avatar {
            font-size: 50px;
            margin-bottom: 10px;
        }

        .user-profile .username {
            margin: 0;
        }

        .rent-btn {
            background-color: black;
            border-color: black;
            color: white;
        }

        .rent-btn:hover {
            background-color: whitesmoke;
            border-color: black;
            color: black;
        }

    </style>
</head>
<body>
    <div class="sidebar">
        <div class="user-profile">
            <span class="avatar"><i class="fas fa-user-circle"></i></span>
            <p class="username"><?php echo $username; ?></p>
        </div>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) === 'RenterCarList.php') ? 'active' : ''; ?>" href="RenterCarList.php">View Available Cars</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) === 'RenterRentalHistory.php') ? 'active' : ''; ?>" href="RenterRentalHistory.php">View Rental History</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">Logout</a>
            </li>
        </ul>
    </div>

    <div class="content border border-dark p-4">
    <h5 class="mb-4">Car Details</h5>
    <div class="card border border-dark">
        <div class="card-body">
            <p class="card-text"><strong>Car No: </strong> <?php echo $car['CarNo']; ?></p>
            <p class="card-text"><strong>Plates: </strong> <?php echo $car['Plates']; ?></p>
            <p class="card-text"><strong>Model: </strong> <?php echo $car['Model']; ?></p>
            <p class="card-text"><strong>Type: </strong> <?php echo $car['Type']; ?></p>
            <p class="card-text"><strong>Cost Per Day: </strong> <?php echo $car['CostPerDay']; ?></p>
        </div>
    </div>
    <br />
    <form method="post">
        <div class="form-group">
            <label for="start_date">Start Date:</label>
            <input type="date" class="form-control border border-dark" id="start_date" name="start_date" required>
        </div>
        <br />
        <div class="form-group">
            <label for="end_date">End Date:</label>
            <input type="date" class="form-control border border-dark" id="end_date" name="end_date" required>
        </div>
        <br />
        <button type="submit" class="btn rent-btn">Rent Car</button>
    </form>
    <br />
    <?php if (isset($errorMessage)) : ?>
    <div class="alert alert-danger"><?php echo $errorMessage; ?></div>
    <?php endif; ?>

    <?php if (!empty($successMessage)) : ?>
    <div class="alert alert-success"><?php echo $successMessage; ?></div>
    <?php endif; ?>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
