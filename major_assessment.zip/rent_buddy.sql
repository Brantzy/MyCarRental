-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 26, 2023 at 01:21 PM
-- Server version: 8.0.32
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rent_buddy`
--

-- --------------------------------------------------------

--
-- Table structure for table `car`
--

DROP TABLE IF EXISTS `car`;
CREATE TABLE IF NOT EXISTS `car` (
  `CarID` int NOT NULL AUTO_INCREMENT,
  `CarNo` varchar(50) NOT NULL,
  `Plates` varchar(50) NOT NULL,
  `Model` varchar(50) NOT NULL,
  `Type` varchar(50) NOT NULL,
  `Status` enum('Available','Rented','Overdue','Returned') NOT NULL DEFAULT 'Available',
  `CostPerDay` decimal(10,2) NOT NULL,
  `CostPerDayOverdue` decimal(10,2) NOT NULL,
  PRIMARY KEY (`CarID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `car`
--

INSERT INTO `car` (`CarID`, `CarNo`, `Plates`, `Model`, `Type`, `Status`, `CostPerDay`, `CostPerDayOverdue`) VALUES
(1, '01', '111000', 'BMW', 'Sedan', 'Available', '150.00', '100.00'),
(2, '02', '423123', 'Ford', 'Hashback', 'Available', '100.00', '50.00'),
(3, '03', '566900', 'Audi', '4 Wheeler', 'Available', '200.00', '120.00'),
(4, '04', '600788', 'Ford', 'Truck', 'Available', '180.00', '110.00'),
(5, '20', '700899', 'Mazda', 'Sedan', 'Available', '290.00', '130.00');

-- --------------------------------------------------------

--
-- Table structure for table `rental`
--

DROP TABLE IF EXISTS `rental`;
CREATE TABLE IF NOT EXISTS `rental` (
  `RentalID` int NOT NULL AUTO_INCREMENT,
  `CarID` int NOT NULL,
  `UserID` int NOT NULL,
  `RentalStartDate` date NOT NULL,
  `RentalEndDate` date NOT NULL,
  `TotalCost` decimal(10,2) NOT NULL,
  PRIMARY KEY (`RentalID`),
  KEY `CarID` (`CarID`),
  KEY `UserID` (`UserID`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `UserID` int NOT NULL AUTO_INCREMENT,
  `Firstname` varchar(50) NOT NULL,
  `Surname` varchar(50) NOT NULL,
  `Phone` varchar(20) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `hashedPassword` varchar(255) NOT NULL,
  `UserType` enum('Administrator','Renter') NOT NULL,
  PRIMARY KEY (`UserID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `Firstname`, `Surname`, `Phone`, `Email`, `hashedPassword`, `UserType`) VALUES
(1, 'Brandon', 'Teh', '0415298189', 'brandontehzy@gmail.com', '$2y$10$ecZ53GYKWeWI0/q6/E70ROtNhAoRQ08op6EVMzdenBlUzhSKZ7sEu', 'Administrator'),
(2, 'James', 'Gunn', '0415298189', 'jamesgun@gmail.com', '$2y$10$NKO23Ky2l3BDnaFk9crdwerusUftspyrNaFImp5s9Fl/3P0i6xcGy', 'Renter');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `rental`
--
ALTER TABLE `rental`
  ADD CONSTRAINT `rental_ibfk_1` FOREIGN KEY (`CarID`) REFERENCES `car` (`CarID`),
  ADD CONSTRAINT `rental_ibfk_2` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
